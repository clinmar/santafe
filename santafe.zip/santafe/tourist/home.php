<?php
include '../db.php';
session_start();

if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['user_email'];

try {
    $stmt = $conn->prepare("SELECT * FROM tourist WHERE email = :email");
    $stmt->bindParam(':email', $user_email);
    $stmt->execute();
    $tourist = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<?php include "../header.php"; ?>

<div class="container">
    <h1>Welcome, <?php echo $tourist['fullname']; ?>!</h1>
</div>

<?php include "../footer.php"; ?>