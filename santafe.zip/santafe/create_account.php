<?php
include ("header.php");
?>
<div class="container mt-5">
    <div class="d-flex justify-content-center">
        <div class="col-8">
            <div class="card">
                <div class="card-header bg-primary">
                    <h1 class="text-center text-white">
                        Create account
                    </h1>
                </div>

                <div class="card-body">
                    <div class="">

                        <form method="POST" action="create_account_process.php">
                            <div class="mb-3">
                                <label for="fullname" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="fullname" name="fullname"
                                    placeholder="Enter your full name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    placeholder="Enter your email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password"
                                    placeholder="Enter your password" required>
                            </div>
                            <a href="login.php" class="btn btn-primary mb-2">Back</a>
                            <button type="submit" class="btn btn-primary w-100">Create Account</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include ("header.php");
?>